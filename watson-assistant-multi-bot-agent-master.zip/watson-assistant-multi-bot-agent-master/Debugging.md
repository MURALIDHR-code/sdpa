app log files
workspace id is incorrect
Assistant username and/or password is/are incorrect
