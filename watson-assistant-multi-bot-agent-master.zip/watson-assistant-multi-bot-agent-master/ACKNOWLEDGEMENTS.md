The interface of this code pattern is taken from the project https://github.com/watson-developer-cloud/assistant-simple. Credit goes to authors who developed the interface.
